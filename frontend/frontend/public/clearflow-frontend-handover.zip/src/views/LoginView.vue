<template>
  <div id="login-view" class="min-h-[85vh] flex items-center justify-center px-4 py-8">
    <div class="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
      <!-- Logo & Brand Header -->
      <div class="text-center space-y-2">
        <div class="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black text-2xl mx-auto shadow-lg shadow-blue-500/20">
          CF
        </div>
        <h1 class="text-2xl font-bold text-slate-100 tracking-tight">ClearFlow Chits</h1>
        <p class="text-xs text-slate-400">
          Small Chits Workflow Automation &bull; Manager Workspace
        </p>
      </div>

      <!-- Google Sign In: Only Login Option -->
      <div class="space-y-4 pt-2">
        <button
          id="google-signin-btn"
          type="button"
          @click="handleGoogleSignIn"
          class="w-full py-3.5 px-4 bg-white hover:bg-slate-100 active:scale-[0.99] text-slate-800 rounded-xl text-sm font-semibold transition-all shadow-md flex items-center justify-center gap-3 border border-slate-200 cursor-pointer"
        >
          <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
          </svg>
          <span>Sign in with Google</span>
        </button>
      </div>

      <!-- Downside Support & Welcome Section -->
      <div class="pt-6 border-t border-slate-800/90 text-center space-y-4">
        <div class="space-y-1">
          <h2 class="text-sm sm:text-base font-bold text-slate-200">
            Welcome to ClearFlow Automations
          </h2>
          <p class="text-xs text-slate-400">
            Call <a href="tel:+919652169196" class="text-blue-400 hover:text-blue-300 font-mono font-semibold underline decoration-dotted">+919652169196</a> for any queries
          </p>
        </div>

        <!-- One-Click WhatsApp Opening Button -->
        <a
          id="whatsapp-contact-btn"
          href="https://wa.me/919652169196?text=Hello%20ClearFlow%20Automations%2C%20I%20have%20a%20query"
          target="_blank"
          rel="noopener noreferrer"
          class="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow flex items-center justify-center gap-2.5 cursor-pointer"
        >
          <svg class="w-4 h-4 text-white shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
          </svg>
          <span>Chat with us on WhatsApp</span>
        </a>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router';
import { useManagerWorkspace } from '../composables/useManagerWorkspace';

const router = useRouter();
const { setCustomerType } = useManagerWorkspace();

const handleGoogleSignIn = () => {
  localStorage.setItem('clearflow_auth_token', 'google_oauth_token_' + Date.now());
  setCustomerType('existing');
  router.push('/');
};
</script>
